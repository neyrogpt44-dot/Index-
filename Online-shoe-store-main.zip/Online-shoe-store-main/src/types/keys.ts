export enum QueryKeys {
  GetTopSales = 'GetTopSales',
  GetCategories = 'GetCategories',
  GetItems = 'GetItems',
  GetItemsMore = 'GetItemsMore',
  GetSearch = 'GetSearch',
  GetOrderItem = 'GetOrderItem',
  PostOrder = 'PostOrder'
}