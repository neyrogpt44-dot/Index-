export enum EndpointApi {
  TopSales = 'api/top-sales',
  Categories = 'api/categories',
  Category = 'api/category',
  Items = 'api/items',
  Item = 'api/item',
  Order = 'api/order'
}